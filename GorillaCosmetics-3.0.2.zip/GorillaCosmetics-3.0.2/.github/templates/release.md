<!-- DISC-ONLY # {HUMAN_NAME} {VERSION} -->
{DESCRIPTION}

Changes:
- 

Now featuring some cosmetics from our amazing Cosmetics Crew!
Materials:
- Colored Ice by GreenMan36
- Outline by GreenMan36
- Animated Galaxy by ojsauce

Hats:
- White Top Hat by antoca
- Rainbow Hat by ExaltedPotato
- Button Eyes by Graze
- Quacamole by NachoEngine
- Detective by ojsauce
- Mining Helmet by Waulta

**Install using [Monke Mod Manager](https://github.com/DeadlyKitten/MonkeModManager/releases/latest)**
<!-- DISC-ONLY *Or download here: <{REPO}/releases/latest>* -->
